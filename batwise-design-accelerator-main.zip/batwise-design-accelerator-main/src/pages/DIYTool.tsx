import { useState } from "react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowRight, Battery, Zap, Calculator, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";

const DIYTool = () => {
  const [minVoltage, setMinVoltage] = useState("");
  const [maxVoltage, setMaxVoltage] = useState("");
  const [maxPower, setMaxPower] = useState("");
  const [minEnergy, setMinEnergy] = useState("");
  const [maxEnergy, setMaxEnergy] = useState("");
  const [targetPrice, setTargetPrice] = useState("");
  const [maxWeight, setMaxWeight] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [maxWidth, setMaxWidth] = useState("");
  const [maxLength, setMaxLength] = useState("");
  const [maxHeight, setMaxHeight] = useState("");
  const [inverter, setInverter] = useState("");
  const [outputVoltage, setOutputVoltage] = useState("");
  const [showResults, setShowResults] = useState(false);

  const handleGenerate = () => {
    setShowResults(true);
  };

  const scrollToCalculator = () => {
    document.getElementById("calculator")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden mt-16 bg-gradient-to-br from-background via-muted/30 to-background">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-72 h-72 bg-accent/5 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: "1s" }} />
        </div>

        <div className="container relative z-10 px-4 py-20 mx-auto text-center animate-fade-in">
          <div className="flex justify-center mb-6">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-accent/10 rounded-full text-accent font-medium">
              <Sparkles size={18} />
              <span>Free DIY Battery Designer</span>
            </div>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold text-foreground mb-6 leading-tight">
            Design your own battery<br />in minutes.
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground mb-10 max-w-3xl mx-auto">
            Enter your specs — we calculate cells, BMS, and relays for you.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={scrollToCalculator}
              size="lg"
              className="text-lg"
            >
              Start Designing
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              variant="outline"
              size="lg"
              className="text-lg"
              asChild
            >
              <Link to="/pricing">Learn More</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Interactive Calculator Section */}
      <section id="calculator" className="py-24 bg-background">
        <div className="container px-4 mx-auto max-w-6xl">
          <div className="text-center mb-12 animate-slide-up">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Battery Design Calculator
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Configure your battery specifications and get instant recommendations
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Input Panel */}
            <Card className="shadow-soft animate-slide-up">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-accent" />
                  Configuration Inputs
                </CardTitle>
                <CardDescription>
                  Enter your battery requirements below
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="minVoltage">Minimum Nominal Voltage (V)</Label>
                    <Input
                      id="minVoltage"
                      type="number"
                      placeholder="e.g., 36"
                      value={minVoltage}
                      onChange={(e) => setMinVoltage(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxVoltage">Maximum Nominal Voltage (V)</Label>
                    <Input
                      id="maxVoltage"
                      type="number"
                      placeholder="e.g., 54.6"
                      value={maxVoltage}
                      onChange={(e) => setMaxVoltage(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxPower">Maximum Power (kW)</Label>
                    <Input
                      id="maxPower"
                      type="number"
                      placeholder="e.g., 5"
                      value={maxPower}
                      onChange={(e) => setMaxPower(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">(Maximum power sustained for 30 seconds)</p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="minEnergy">Minimum Energy (kWh)</Label>
                    <Input
                      id="minEnergy"
                      type="number"
                      placeholder="e.g., 2"
                      value={minEnergy}
                      onChange={(e) => setMinEnergy(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxEnergy">Maximum Energy (kWh)</Label>
                    <Input
                      id="maxEnergy"
                      type="number"
                      placeholder="e.g., 5"
                      value={maxEnergy}
                      onChange={(e) => setMaxEnergy(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="targetPrice">Target Price (€)</Label>
                    <Input
                      id="targetPrice"
                      type="number"
                      placeholder="e.g., 500"
                      value={targetPrice}
                      onChange={(e) => setTargetPrice(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxWeight">Maximum Weight (kg)</Label>
                    <Input
                      id="maxWeight"
                      type="number"
                      placeholder="e.g., 30"
                      value={maxWeight}
                      onChange={(e) => setMaxWeight(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxPrice">Maximum Price (€)</Label>
                    <Input
                      id="maxPrice"
                      type="number"
                      placeholder="e.g., 1000"
                      value={maxPrice}
                      onChange={(e) => setMaxPrice(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxWidth">Maximum Width (mm)</Label>
                    <Input
                      id="maxWidth"
                      type="number"
                      placeholder="e.g., 300"
                      value={maxWidth}
                      onChange={(e) => setMaxWidth(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxLength">Maximum Length (mm)</Label>
                    <Input
                      id="maxLength"
                      type="number"
                      placeholder="e.g., 400"
                      value={maxLength}
                      onChange={(e) => setMaxLength(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxHeight">Maximum Height (mm)</Label>
                    <Input
                      id="maxHeight"
                      type="number"
                      placeholder="e.g., 200"
                      value={maxHeight}
                      onChange={(e) => setMaxHeight(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="inverter">Inverter</Label>
                    <Select value={inverter} onValueChange={setInverter}>
                      <SelectTrigger id="inverter">
                        <SelectValue placeholder="Select inverter type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="car">Car Inverter</SelectItem>
                        <SelectItem value="home">Home Inverter</SelectItem>
                        <SelectItem value="none">No Inverter</SelectItem>
                        <SelectItem value="other">Inverter for other application</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {inverter === "other" && (
                    <div className="space-y-2">
                      <Label htmlFor="outputVoltage">Output Voltage (V)</Label>
                      <Input
                        id="outputVoltage"
                        type="number"
                        placeholder="e.g., 230"
                        value={outputVoltage}
                        onChange={(e) => setOutputVoltage(e.target.value)}
                      />
                    </div>
                  )}
                </div>

                <Button 
                  onClick={handleGenerate} 
                  className="w-full"
                  size="lg"
                >
                  <Zap className="mr-2 h-5 w-5" />
                  Generate Design
                </Button>
              </CardContent>
            </Card>

            {/* Output Panel */}
            <Card className="shadow-soft animate-slide-up" style={{ animationDelay: "100ms" }}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Battery className="w-5 h-5 text-accent" />
                  Suggested Configuration
                </CardTitle>
                <CardDescription>
                  Your optimized battery design
                </CardDescription>
              </CardHeader>
              <CardContent>
                {showResults ? (
                  <div className="space-y-6">
                    <div className="p-4 bg-muted rounded-lg">
                      <h3 className="font-semibold text-foreground mb-3">Configuration</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Cells in Series:</span>
                          <span className="font-medium">13S</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Cells in Parallel:</span>
                          <span className="font-medium">4P</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Total Cells:</span>
                          <span className="font-medium">52 cells</span>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-muted rounded-lg">
                      <h3 className="font-semibold text-foreground mb-3">Components</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">BMS:</span>
                          <span className="font-medium">13S 100A</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Relay:</span>
                          <span className="font-medium">200A Contactor</span>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-accent/10 rounded-lg border border-accent/20">
                      <h3 className="font-semibold text-foreground mb-2">Estimated Cost</h3>
                      <p className="text-3xl font-bold text-accent">€380 - €450</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Based on current market prices
                      </p>
                    </div>

                    <div className="pt-4 border-t border-border">
                      <p className="text-sm text-muted-foreground mb-3">
                        🔒 Unlock detailed specifications, component recommendations, and PDF export
                      </p>
                      <Button variant="outline" className="w-full" asChild>
                        <Link to="/pricing">Upgrade to Professional Version</Link>
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full min-h-[400px] text-center">
                    <Battery className="w-16 h-16 text-muted-foreground/30 mb-4" />
                    <p className="text-muted-foreground">
                      Enter your specifications and click<br />"Generate Report" to see results
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Free vs Pro Banner */}
      <section className="py-24 bg-muted/30">
        <div className="container px-4 mx-auto max-w-4xl text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
            Use our free version or unlock advanced features
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Get started with basic calculations for free, or upgrade for professional-grade tools
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="outline" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
              Try Free Version
            </Button>
            <Button size="lg" asChild>
              <Link to="/pricing">Upgrade to Professional Version</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default DIYTool;
